use amethyst::{
    assets::{AssetStorage, Handle, Loader},
    core::math as na,
    core::transform::Transform,
    input::{is_close_requested, is_key_down, VirtualKeyCode},
    prelude::*,
    renderer::{Camera, ImageFormat, SpriteRender, SpriteSheet, SpriteSheetFormat, Texture},
    window::ScreenDimensions,
};

use crate::config::TankConfig;
//use crate::physics::Physics;
use crate::tank::{Tank, Team};
use crate::level::MazeLevel;

#[derive(Default)]
pub struct SpriteSheetRes {
    pub handle: Option<Handle<SpriteSheet>>,
}

pub struct MyState;
impl SimpleState for MyState {
    // On start will run when this state is initialized.
    fn on_start(&mut self, data: StateData<'_, GameData<'_, '_>>) {
        let world = data.world;

        // Get the screen dimensions so we can initialize the camera and
        // place our sprites correctly later. We'll clone this since we'll
        // pass the world mutably to the following functions.
        let dimensions = (*world.read_resource::<ScreenDimensions>()).clone();

        // Place the camera
        init_camera(world, &dimensions);

        // Load our sprites and display them
        let sprite_sheet_handle = load_sprite_sheet(world);
        let ss_handle_res = SpriteSheetRes {
            handle: Some(sprite_sheet_handle.clone()),
        };
        world.insert(ss_handle_res);

        //Initialize players
        init_tanks(world, sprite_sheet_handle, &dimensions);

        //Initialize the maze
        init_maze(world);
    }

    fn handle_event(
        &mut self,
        mut _data: StateData<'_, GameData<'_, '_>>,
        event: StateEvent,
    ) -> SimpleTrans {
        if let StateEvent::Window(event) = &event {
            // Check if the window should be closed
            if is_close_requested(&event) || is_key_down(&event, VirtualKeyCode::Escape) {
                return Trans::Quit;
            }

            // Listen to any key events
            //if let Some(event) = get_key(&event) {
            //    info!("handling key event: {:?}", event);
            //}
        }
        // Keep going
        Trans::None
    }
}

fn init_camera(world: &mut World, dimensions: &ScreenDimensions) {
    // Center the camera in the middle of the screen, and let it cover
    // the entire screen
    let mut transform = Transform::default();
    transform.set_translation_xyz(dimensions.width() * 0.5, dimensions.height() * 0.5, 1.);

    world
        .create_entity()
        .with(Camera::standard_2d(dimensions.width(), dimensions.height()))
        .with(transform)
        .build();
}

fn load_sprite_sheet(world: &mut World) -> Handle<SpriteSheet> {
    // Load the texture for our sprites. We'll later need to
    // add a handle to this texture to our `SpriteRender`s, so
    // we need to keep a reference to it.
    let texture_handle = {
        let loader = world.read_resource::<Loader>();
        let texture_storage = world.read_resource::<AssetStorage<Texture>>();
        loader.load(
            "sprites/tanks.png",
            ImageFormat::default(),
            (),
            &texture_storage,
        )
    };

    // Load the spritesheet definition file, which contains metadata on our
    // spritesheet texture.
    let loader = world.read_resource::<Loader>();
    let sheet_storage = world.read_resource::<AssetStorage<SpriteSheet>>();
    return loader.load(
        "sprites/tanks.ron",
        SpriteSheetFormat(texture_handle),
        (),
        &sheet_storage,
    );
}

fn init_maze(world: &mut World) {
    let maze_res = MazeLevel::new(world);

    world.insert(maze_res);
}

fn init_tanks(world: &mut World, sheet_handle: Handle<SpriteSheet>, dimensions: &ScreenDimensions) {
    let sprites: Vec<SpriteRender> = (0..2)
        .map(|i| SpriteRender {
            sprite_sheet: sheet_handle.clone(),
            sprite_number: i,
        })
        .collect();

    //TODO: Refactor
    let x = dimensions.width() * 0.5;
    let y = dimensions.height() * 0.5;
    let mut red_trans = Transform::default();
    red_trans.set_translation_xyz(x, y, 0.);
    let x = dimensions.width() * 0.5;
    let y = dimensions.height() * 0.5;
    let mut blue_trans = Transform::default();
    blue_trans.set_translation_xyz(x + 50.0, y, 0.);

    let red_pos = na::Isometry2::from_parts(
        na::Translation::from(na::Vector2::new(x, y)),
        na::UnitComplex::new(0.0),
    );
    let blue_pos = na::Isometry2::from_parts(
        na::Translation::from(na::Vector2::new(x + 50.0, y)),
        na::UnitComplex::new(0.0)
    );

    use specs_physics::{
        ncollide::shape::{ShapeHandle, Cuboid},
        nphysics::{
            object::{ColliderDesc, RigidBody, RigidBodyDesc}
        },
        BodyComponent, EntityBuilderExt
    };

    let tank_config = (*world.read_resource::<TankConfig>()).clone();

    let tank_shape = ShapeHandle::new(Cuboid::new(na::Vector2::new(
        tank_config.size_x as f32 * 0.5,
        tank_config.size_y as f32 * 0.5,
    )));

    let tank_collider =
        ColliderDesc::new(tank_shape.clone()).density(1.0);

    println!("Config: {:?}", tank_config);

    //Create the Red Tank
    world
        .create_entity()
        .with(Tank::new(Team::Red))
        .with(sprites[0].clone())
        .with(red_trans)
        .with_body::<f32, _>(
            RigidBodyDesc::new()
                .position(red_pos)
                //.set_linear_damping(tank_config.linear_damping)
                //.set_angular_damping(tank_config.angular_damping)
                .set_max_linear_velocity(tank_config.max_linear_vel)
                //.set_max_angular_velocity(tank_config.max_angular_vel)
                .build(),
        )
        .with_collider::<f32>(&tank_collider)
        .build();

    //Create the Blue Tank
    world
        .create_entity()
        .with(Tank::new(Team::Blue))
        .with(sprites[1].clone())
        .with_body::<f32, _>(
            RigidBodyDesc::new()
                .position(blue_pos)
                //.set_linear_damping(tank_config.linear_damping)
                //.set_angular_damping(tank_config.angular_damping)
                .set_max_linear_velocity(tank_config.max_linear_vel)
                //.set_max_angular_velocity(tank_config.max_angular_vel)
                .build(),
        )
        .with_collider::<f32>(&tank_collider)
        .with(blue_trans)
        .build();
}