use amethyst::{
    core::math as na,
    core::Transform,
    core::timing::Time,
    ecs::{
        Component, DenseVecStorage, Entities, Join, Read, Write, ReadExpect, ReadStorage, System,
        WriteStorage,
    },
    input::{InputHandler, StringBindings},
    renderer::SpriteRender,
    renderer::debug_drawing::DebugLines,
    renderer::palette::Srgba,
};

use crate::config::BulletConfig;
use crate::state::SpriteSheetRes;
use crate::tank::*;

pub struct Projectile {
    pub lifetime: u32,
    pub radius: f32,
}

impl Component for Projectile {
    type Storage = DenseVecStorage<Self>;
}

use specs_physics::{
    ncollide::shape::{Ball, ShapeHandle},
    nphysics::object::{RigidBody, RigidBodyDesc, ColliderDesc, BodyPartHandle},
    nphysics::algebra::Velocity2,
    bodies::WriteRigidBodies,
    BodyComponent, ColliderComponent
};

pub struct ProjectileSystem;

impl<'s> System<'s> for ProjectileSystem {
    type SystemData = (
        Read<'s, InputHandler<StringBindings>>,
        Read<'s, SpriteSheetRes>,
        WriteStorage<'s, SpriteRender>,

        Entities<'s>,
        WriteStorage<'s, BodyComponent<f32>>,
        WriteStorage<'s, ColliderComponent<f32>>,
        WriteStorage<'s, Transform>,

        WriteStorage<'s, Tank>,
        WriteStorage<'s, Projectile>,

        Read<'s, BulletConfig>,

        Read<'s, Time>,
        Write<'s, DebugLines>,
    );

    fn run(
        &mut self,
        (
            input,
            ss_handle,
            mut sprite_renders,

            entities,
            mut body_components,
            mut collider_components,
            mut transforms,
            mut tanks,
            mut projectiles_data,
            b_config,
            time,
            mut debug_lines,
        ): Self::SystemData,

    ) {

        //Vector of projectiles to add to the simulation: (position, direction)
        //Direction is not normalized - it already takes the fire speed into account
        let mut projectiles = Vec::<(na::Vector2<f32>, na::Vector2<f32>)>::new();

        //Check for shooting tanks, apply recoil and calculate new projectiles
        for (tank, mut body) in (&mut tanks, &mut body_components).join() {
            let fire = match tank.team {
                Team::Red => input.action_is_down("p1_fire"),
                Team::Blue => input.action_is_down("p2_fire"),
            };

            let body = body.downcast_mut::<RigidBody<f32>>().unwrap();


            if let Some(shoot) = fire {
                if shoot && tank.weapon_timeout.is_none() {
                    //Set weapon timeout
                    tank.weapon_timeout.replace(0.8);

                    //Shooting recoil
                    let recoil_vec = body.position().rotation * na::Vector2::new(0.0, -1.0 * 30_000.0);
                    //set_linear_velocity() (?)
                    //body.set_velocity(
                    //    *body.velocity() + Velocity2::linear(recoil_vec.x, recoil_vec.y)
                    //);

                    let fire_vector = body.position().rotation
                        * na::Vector2::new(0.0, b_config.speed);

                    projectiles.push((body.position().translation.vector, fire_vector));
                }
            }

            //Decrease the weapon timeout
            if let Some(mut timeout) = tank.weapon_timeout.take() {
                timeout -= time.delta_seconds();
                if timeout <= 0.0 {
                    tank.weapon_timeout = None;
                } else {
                    tank.weapon_timeout.replace(timeout);
                }
            }
        }

        for (position, direction) in projectiles {
            let sprite_render = SpriteRender {
                sprite_sheet: ss_handle.handle.as_ref().unwrap().clone(),
                sprite_number: b_config.sprite_num,
            };

            //Sprite's position
            let mut proj_transform = Transform::default();
            proj_transform.set_translation_xyz(
                position.x,
                position.y,
                0.8,
            );

            //Projectile description (lifetime and radius)
            let projectile = Projectile {
                lifetime: b_config.max_lifetime,
                radius: b_config.radius,
            };

            //Projectile's collider
            //Move out of the loop (?)
            let proj_collider = ColliderDesc::new(
                ShapeHandle::new(
                    Ball::new(b_config.radius)
                )
            ).density(2.0);

            //Projectile's rigid body
            let rb = RigidBodyDesc::new()
                .translation(position)
                .velocity(Velocity2::linear(direction.x, direction.y)).build();

            let entity_builder = entities
                .build_entity()
                .with(sprite_render, &mut sprite_renders)
                .with(projectile, &mut projectiles_data)
                .with(proj_transform, &mut transforms)
                .with(BodyComponent::new(rb), &mut body_components);

            let collider_component = ColliderComponent(
                proj_collider.build(BodyPartHandle(entity_builder.entity, 0))
            );

            entity_builder.with(collider_component, &mut collider_components).build();
        }

        //Do operations on all projectiles
        //for (projectile, entity, p_physics) in (&mut projectiles_data, &entities, &physics).join() {

        //    let p_rb_tag = p_physics.rb_handle.as_ref().unwrap().get();
        //    debug_lines.draw_circle(
        //        na::Point3::from(rb_serv.transform(p_rb_tag).translation.vector),
        //        b_config.radius,
        //        8,
        //        Srgba::new(0.0, 1.0, 0.0, 1.0),
        //    );

        //    //Check for collisions
        //    let mut contacts: Vec<ContactEvent<f32>> = Vec::new();
        //    rb_serv.contact_events(p_rb_tag, &mut contacts);

        //    //for contact in contacts.iter() {
        //    //    for (tank, t_phys) in (&tanks, &physics).join() {
        //    //        let tank_rb_tag = t_phys.rb_handle.as_ref().unwrap().get();
        //    //        if contact.other_body == tank_rb_tag {
        //    //            match &tank.team {
        //    //                Team::Blue => println!("Blue tank hit"),
        //    //                Team::Red => println!("Red tank hit")
        //    //            }
        //    //        }
        //    //    }
        //    //}
        //}
    }
}
