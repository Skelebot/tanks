extern crate serde;
use amethyst::{
    core::transform::TransformBundle,
    core::transform::Transform,
    prelude::*,
    renderer::{
        plugins::{RenderFlat2D, RenderToWindow, RenderDebugLines},
        types::DefaultBackend,
        RenderingBundle,
    },
    input::{InputBundle, StringBindings},
    utils::application_root_dir,
};

use specs_physics::{
    nalgebra as na,
    PhysicsBundle
};


use std::time::Duration;
use amethyst::core::frame_limiter::FrameRateLimitStrategy;

mod state;
mod level;
mod remove;
pub mod tank;
pub mod projectile;
pub mod config;
pub mod mazegen;

use config::{BulletConfig, InputConfig, TankConfig};

fn main() -> amethyst::Result<()> {
    amethyst::start_logger(Default::default());

    let app_root = application_root_dir()?;
let resources = app_root.join("resources");
    let display_config = resources.join("display_config.ron");
    let binding_path = resources.join("bindings.ron");

    let input_bundle = InputBundle::<StringBindings>::new()
        .with_bindings_from_file(binding_path)?;

    //Configs
    let bullet_config = BulletConfig::load(resources.join("bullet_conf.ron"));
    let input_config = InputConfig::load(resources.join("input_conf.ron"));
    let tank_config = TankConfig::load(resources.join("tank_conf.ron"));

    let physics_bundle = PhysicsBundle::<f32, Transform>::new(na::Vector::y() * 0.0, &[]);

    let game_data = GameDataBuilder::default()
        .with_bundle(TransformBundle::new())?
        .with_bundle(input_bundle)?
        .with_bundle(physics_bundle)?
        .with(tank::TankSystem, "tank_system", &["input_system"])
        //.with(projectile::ProjectileSystem, "projectile_system", &["tank_system"])
        //.with(remove::RemoveSystem, "remove_system", &["projectile_system"])
        .with_bundle(
            RenderingBundle::<DefaultBackend>::new()
                .with_plugin(
                    RenderToWindow::from_config_path(display_config)?
                        .with_clear([1.0, 1.0, 1.0, 1.0]),
                )
                .with_plugin(RenderFlat2D::default())
                .with_plugin(RenderDebugLines::default())
        )?;


    let mut game = Application::build(resources, state::MyState)?
        .with_resource(bullet_config)
        .with_resource(input_config)
        .with_resource(tank_config)
        .with_frame_limit(
            FrameRateLimitStrategy::SleepAndYield(Duration::from_millis(2)),
            60
        )
        .build(game_data)?;
    game.run();

    Ok(())
}
