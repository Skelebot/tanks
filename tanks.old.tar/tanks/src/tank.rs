use amethyst::{
    core::math as na,
    core::timing::Time, //Delta time
    ecs::{Component, DenseVecStorage, Join, Read, ReadStorage, System, WriteStorage},
    input::{InputHandler, StringBindings},
};

use crate::config::{InputConfig, TankConfig};

pub const TANK_SIZE: f32 = 6.0;

#[derive(PartialEq, Eq, Debug)]
pub enum Team {
    Red,
    Blue,
}

pub struct Tank {
    pub team: Team,
    pub size: f32,
    pub weapon_timeout: Option<f32>,
    //shoot timeout
    //weapon
    //ammo
}

impl Tank {
    pub fn new(team: Team) -> Self {
        Tank {
            team,
            size: TANK_SIZE,
            weapon_timeout: None,
        }
    }
}

impl Component for Tank {
    type Storage = DenseVecStorage<Self>;
}

use specs_physics::{
    nphysics::object::{RigidBody},
    nphysics::algebra::Velocity2,
    BodyComponent,
};

pub struct TankSystem;

impl<'s> System<'s> for TankSystem {
    type SystemData = (
        ReadStorage<'s, Tank>,
        WriteStorage<'s, BodyComponent<f32>>,
        Read<'s, InputHandler<StringBindings>>,
        Read<'s, InputConfig>,
        Read<'s, TankConfig>,
        Read<'s, Time>, //Delta time
    );

    fn run(
        &mut self,
        (tanks, mut bodies, input, _input_config, tank_config, _time): Self::SystemData,
    ) {
        for (tank, body) in (&tanks, &mut bodies).join() {
            //This can panic. Hard.
            let body = body.downcast_mut::<RigidBody<f32>>().unwrap();
            //TODO: Parametric input &str-s for arbitrary number of players
            let (mov_forward, mov_side) = match tank.team {
                Team::Red => (
                    input.axis_value("p1_forward"),
                    input.axis_value("p1_side"),
                ),
                Team::Blue => (
                    input.axis_value("p2_forward"),
                    input.axis_value("p2_side"),
                ),
            };

            //Change tank velocity
            let mut movement = na::Vector2::repeat(0.0);
            //Check if there is forward/backward movement
            if let Some(fwd) = mov_forward {
                movement.y += fwd;
            }
            //Check if there is right/left movement
            if let Some(side) = mov_side {
                movement.x += side;
            }

            //Movement relative to the tank's front
            let mov_rel = body.position().rotation
                * na::Vector2::new(0.0, movement.y * tank_config.accel);


            //TODO: Delta
            //Move the tank forward and backward
            //Rotate the tank
            body.set_velocity(
                *body.velocity() + 
                Velocity2::new(
                    na::Vector2::new(mov_rel.x, mov_rel.y),
                    movement.x * tank_config.angular_accel
                )
            );
        }
    }
}

fn limit_magnitude(vector: &na::Vector3<f32>, mag: f32) -> na::Vector3<f32> {
    if vector.norm() > mag {
        return vector * (mag / vector.norm());
    } else {
        return *vector;
    }
}