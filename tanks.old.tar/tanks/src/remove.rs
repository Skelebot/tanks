use amethyst::{
    ecs::{System, Read, Join, WriteStorage, ReadStorage, ReadExpect, World, WorldExt, Entities}
};

use crate::config::BulletConfig;
use crate::projectile::Projectile;

pub struct RemoveSystem;

impl <'s> System<'s> for RemoveSystem {
    type SystemData = (
        Entities<'s>,
        WriteStorage<'s, Projectile>,
        Read<'s, BulletConfig>,
    );

    fn run(&mut self, (entities, mut projectiles, b_config): Self::SystemData) {
        //Delete the projectile if the lifetime exceeds the max lifetime
        for (projectile, entity) in (&mut projectiles, &entities).join() {
            if projectile.lifetime > b_config.max_lifetime {
                entities
                    .delete(entity)
                    .expect("Cannot remove projectile");
            } else {
                //TODO: Use Time instead
                projectile.lifetime += 1;
            }
        }
    }
}